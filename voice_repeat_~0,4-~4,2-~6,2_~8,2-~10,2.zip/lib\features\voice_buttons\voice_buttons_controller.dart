import 'package:flutter/foundation.dart';
import '../../data/repositories/ritual_repo.dart';
import '../../infrastructure/audio_service.dart';
import '../../infrastructure/file_storage.dart';

class VoiceButtonsController extends ChangeNotifier {
  VoiceButtonsController({
    required this.repo,
    required this.audio,
    required this.storage,
    required this.personId,
  });

  final RitualRepo repo;
  final AudioService audio;
  final FileStorage storage;
  final String personId;

  String? recordingItemId;
  String? playingItemId;

  final Map<String, String> _recordingPathByItemId = {};

  Future<void> startHold(String itemId) async {
    if (recordingItemId != null) return;

    final ok = await audio.hasMicPermission();
    if (!ok) return;

    final path = await storage.newActivePath(itemId);
    _recordingPathByItemId[itemId] = path;

    recordingItemId = itemId;
    notifyListeners();

    try {
      await audio.startRecording(path);
    } catch (_) {
      recordingItemId = null;
      _recordingPathByItemId.remove(itemId);
      notifyListeners();
    }
  }

  Future<void> stopHold(String itemId) async {
    if (recordingItemId != itemId) return;

    try {
      await audio.stopRecording();
    } catch (_) {}

    final path = _recordingPathByItemId.remove(itemId) ?? await storage.newActivePath(itemId);
    final size = await storage.fileSize(path);

    recordingItemId = null;
    notifyListeners();

    // Guard: do not commit empty recordings
    if (size <= 0) {
      await storage.deleteIfExists(path);
      return;
    }

    await repo.setRecorded(
      personId: personId,
      itemId: itemId,
      label: '',
      activePath: path,
      sizeBytes: size,
    );
  }

  Future<void> togglePlay(String itemId, String path) async {
    if (playingItemId == itemId) {
      await audio.stopPlay();
      playingItemId = null;
      notifyListeners();
      return;
    }

    await audio.stopPlay();
    playingItemId = itemId;
    notifyListeners();

    await audio.playFile(path);

    playingItemId = null;
    notifyListeners();
  }

  Future<void> archive(String itemId, String activePath) async {
    final to = await storage.archivePath(itemId);
    await storage.move(activePath, to);
    await repo.setArchived(personId: personId, itemId: itemId, archivedPath: to);
  }

  Future<void> restore(String itemId, String archivedPath) async {
    final to = await storage.newActivePath(itemId);
    await storage.move(archivedPath, to);
    await repo.restore(personId: personId, itemId: itemId, activePath: to);
  }

  Future<void> deleteActive(String itemId, {String? activePath}) async {
    if (activePath != null) {
      await storage.deleteIfExists(activePath);
    }
    await repo.clearToEmpty(personId: personId, itemId: itemId);
  }

  Future<void> deleteArchived(String itemId, {String? archivedPath}) async {
    if (archivedPath != null) {
      await storage.deleteIfExists(archivedPath);
    }
    await repo.clearToEmpty(personId: personId, itemId: itemId);
  }

  @override
  void dispose() {
    audio.dispose();
    super.dispose();
  }
}