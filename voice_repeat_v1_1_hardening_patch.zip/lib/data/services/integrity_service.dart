import 'dart:async';

import 'package:drift/drift.dart' as drift;

import '../../infrastructure/file_storage.dart';
import '../db/app_db.dart';
import '../repositories/ritual_repo.dart';

class IntegritySummary {
  final int checked;
  final int ok;
  final int issues;
  final int fixed;

  const IntegritySummary({
    required this.checked,
    required this.ok,
    required this.issues,
    required this.fixed,
  });
}

class IntegrityService {
  IntegrityService({
    required this.db,
    required this.repo,
    required this.storage,
  });

  final AppDb db;
  final RitualRepo repo;
  final FileStorage storage;

  int _now() => DateTime.now().millisecondsSinceEpoch;

  Future<IntegritySummary> checkPerson({
    required String personId,
    bool allowAutoFixPathMismatch = true,
  }) async {
    final now = _now();

    var checked = 0;
    var ok = 0;
    var issues = 0;
    var fixed = 0;

    final items = await (db.select(db.ritualItems)..where((t) => t.personId.equals(personId))).get();

    for (final it in items) {
      checked++;

      final res = await _checkItem(it, allowAutoFixPathMismatch: allowAutoFixPathMismatch);

      if (res.didFix) fixed++;

      if (res.status == RitualRepo.integrityOk) {
        ok++;
      } else {
        issues++;
        await repo.logEvent(
          personId: personId,
          itemId: it.itemId,
          type: RitualEventType.integrityIssueDetected,
          metadata: {
            'status': res.status,
            'state': it.state,
            'activePath': it.activePath,
            'archivedPath': it.archivedPath,
            'detail': res.detail,
          },
        );
      }

      if (res.didFix) {
        await repo.logEvent(
          personId: personId,
          itemId: it.itemId,
          type: RitualEventType.integrityAutoFixed,
          metadata: {
            'fix': res.fixApplied,
            'detail': res.detail,
          },
        );
      }

      // Always persist status and checkedAt. We do not log an event per ok item.
      await (db.update(db.ritualItems)..where((t) => t.itemId.equals(it.itemId))).write(
        RitualItemsCompanion(
          integrityStatus: drift.Value(res.status),
          integrityCheckedAt: drift.Value(now),
          activePath: res.newActivePath == null ? const drift.Value.absent() : drift.Value(res.newActivePath),
          archivedPath: res.newArchivedPath == null ? const drift.Value.absent() : drift.Value(res.newArchivedPath),
        ),
      );
    }

    await repo.logEvent(
      personId: personId,
      itemId: 'system',
      type: RitualEventType.integrityChecked,
      metadata: {
        'checked': checked,
        'ok': ok,
        'issues': issues,
        'fixed': fixed,
      },
    );

    return IntegritySummary(checked: checked, ok: ok, issues: issues, fixed: fixed);
  }

  Future<_ItemCheckResult> _checkItem(
    RitualItem it, {
    required bool allowAutoFixPathMismatch,
  }) async {
    // Only enforce file integrity for recorded and archived.
    if (it.state == RitualRepo.stateEmpty) {
      return const _ItemCheckResult(status: RitualRepo.integrityOk);
    }

    if (it.state == RitualRepo.stateRecorded) {
      final stored = it.activePath;
      if (stored == null || stored.isEmpty) {
        return const _ItemCheckResult(status: RitualRepo.integrityMissingPath, detail: 'activePath missing');
      }

      if (await storage.fileExists(stored)) {
        return const _ItemCheckResult(status: RitualRepo.integrityOk);
      }

      // If stored path missing, check expected deterministic path
      final expected = await storage.newActivePath(it.itemId);
      if (stored != expected && await storage.fileExists(expected) && allowAutoFixPathMismatch) {
        return _ItemCheckResult(
          status: RitualRepo.integrityOk,
          didFix: true,
          fixApplied: 'updateActivePathToExpected',
          detail: 'stored file missing, expected file exists',
          newActivePath: expected,
        );
      }

      return const _ItemCheckResult(status: RitualRepo.integrityMissingFile, detail: 'active file missing');
    }

    if (it.state == RitualRepo.stateArchived) {
      final stored = it.archivedPath;
      if (stored == null || stored.isEmpty) {
        return const _ItemCheckResult(status: RitualRepo.integrityMissingPath, detail: 'archivedPath missing');
      }

      if (await storage.fileExists(stored)) {
        return const _ItemCheckResult(status: RitualRepo.integrityOk);
      }

      final expected = await storage.archivePath(it.itemId);
      if (stored != expected && await storage.fileExists(expected) && allowAutoFixPathMismatch) {
        return _ItemCheckResult(
          status: RitualRepo.integrityOk,
          didFix: true,
          fixApplied: 'updateArchivedPathToExpected',
          detail: 'stored file missing, expected file exists',
          newArchivedPath: expected,
        );
      }

      return const _ItemCheckResult(status: RitualRepo.integrityMissingFile, detail: 'archived file missing');
    }

    // Unknown state: keep safe
    return const _ItemCheckResult(status: RitualRepo.integrityOk);
  }
}

class _ItemCheckResult {
  final String status;
  final String? detail;
  final bool didFix;
  final String? fixApplied;
  final String? newActivePath;
  final String? newArchivedPath;

  const _ItemCheckResult({
    required this.status,
    this.detail,
    this.didFix = false,
    this.fixApplied,
    this.newActivePath,
    this.newArchivedPath,
  });
}
