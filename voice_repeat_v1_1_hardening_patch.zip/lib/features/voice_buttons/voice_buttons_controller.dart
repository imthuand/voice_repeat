import 'package:flutter/foundation.dart';
import '../../data/repositories/ritual_repo.dart';
import '../../data/services/integrity_service.dart';
import '../../infrastructure/audio_service.dart';
import '../../infrastructure/file_storage.dart';

class UiMessage {
  final int id;
  final String text;
  const UiMessage(this.id, this.text);
}

class VoiceButtonsController extends ChangeNotifier {
  VoiceButtonsController({
    required this.repo,
    required this.audio,
    required this.storage,
    required this.personId,
  });

  final RitualRepo repo;
  final AudioService audio;
  final FileStorage storage;
  final String personId;

  late final IntegrityService integrity = IntegrityService(db: repo.db, repo: repo, storage: storage);

  String? recordingItemId;
  String? playingItemId;

  UiMessage? uiMessage;
  int _uiMessageSeq = 0;

  final Map<String, String> _recordingPathByItemId = {};

  void _emitUi(String text) {
    _uiMessageSeq++;
    uiMessage = UiMessage(_uiMessageSeq, text);
    notifyListeners();
  }

  Future<void> startHold(String itemId) async {
    if (recordingItemId != null) return;

    final ok = await audio.hasMicPermission();
    if (!ok) {
      _emitUi('Microphone permission is required.');
      return;
    }

    final path = await storage.newActivePath(itemId);
    _recordingPathByItemId[itemId] = path;

    recordingItemId = itemId;
    notifyListeners();

    try {
      await audio.startRecording(path);
    } catch (_) {
      recordingItemId = null;
      _recordingPathByItemId.remove(itemId);
      _emitUi('Recording failed to start.');
      notifyListeners();
    }
  }

  Future<void> stopHold(String itemId) async {
    if (recordingItemId != itemId) return;

    try {
      await audio.stopRecording();
    } catch (_) {}

    final path = _recordingPathByItemId.remove(itemId) ?? await storage.newActivePath(itemId);
    final size = await storage.fileSize(path);

    recordingItemId = null;
    notifyListeners();

    // Guard: do not commit empty recordings
    if (size <= 0) {
      await storage.deleteIfExists(path);
      _emitUi('Recording was empty and was discarded.');
      return;
    }

    await repo.setRecorded(
      personId: personId,
      itemId: itemId,
      label: '',
      activePath: path,
      sizeBytes: size,
    );
  }

  Future<bool> togglePlay(String itemId, String path) async {
    if (playingItemId == itemId) {
      await audio.stopPlay();
      playingItemId = null;
      notifyListeners();
      return false;
    }

    await audio.stopPlay();
    playingItemId = itemId;
    notifyListeners();

    final exists = await storage.fileExists(path);
    if (!exists) {
      playingItemId = null;
      _emitUi('Audio file is missing.');
      return false;
    }

    try {
      await audio.playFile(path);
    } catch (_) {
      _emitUi('Playback failed.');
      playingItemId = null;
      return false;
    }

    playingItemId = null;
    notifyListeners();

    return true;
  }

  Future<void> archive(String itemId, String activePath) async {
    final exists = await storage.fileExists(activePath);
    if (!exists) {
      _emitUi('Cannot archive. Audio file is missing.');
      return;
    }
    final to = await storage.archivePath(itemId);
    await storage.move(activePath, to);
    await repo.setArchived(personId: personId, itemId: itemId, archivedPath: to);
  }

  Future<void> restore(String itemId, String archivedPath) async {
    final exists = await storage.fileExists(archivedPath);
    if (!exists) {
      _emitUi('Cannot restore. Audio file is missing.');
      return;
    }
    final to = await storage.newActivePath(itemId);
    await storage.move(archivedPath, to);
    await repo.restore(personId: personId, itemId: itemId, activePath: to);
  }

  Future<void> deleteActive(String itemId, {String? activePath}) async {
    if (activePath != null) {
      await storage.deleteIfExists(activePath);
    }
    await repo.clearToEmpty(personId: personId, itemId: itemId);
    _emitUi('Slot cleared.');
  }

  Future<void> deleteArchived(String itemId, {String? archivedPath}) async {
    if (archivedPath != null) {
      await storage.deleteIfExists(archivedPath);
    }
    await repo.clearToEmpty(personId: personId, itemId: itemId);
    _emitUi('Slot cleared.');
  }

  Future<IntegritySummary> runIntegrityCheck() async {
    final summary = await integrity.checkPerson(personId: personId);
    _emitUi('Integrity check done. Checked ${summary.checked}. Issues ${summary.issues}. Fixed ${summary.fixed}.');
    return summary;
  }

  @override
  void dispose() {
    audio.dispose();
    super.dispose();
  }
}